#!/usr/bin/env python3
# -*- coding:utf-8 -*-
#
# @name   : PhoneInfoga - Phone numbers OSINT tool
# @url    : https://github.com/sundowndev
# @author : Raphael Cerveaux (sundowndev)

google_api_key=''
google_cx_id=''

firefox_path = '' # change the path according to your needs (e.g: /usr/bin/firefox).